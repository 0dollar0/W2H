<div class="header">
    <div class="header1"><img src="images/logo.jpg" width="229" height="36" /></div>
    <div class="header2">
      <div id="container">
        <div id="mainmenu">
          <ul>
            <li><a class="current a" href="index.php">&nbsp;Home&nbsp;</a></li>
            <li><a href="register.php" class="a">Register</a></li>
            <li><a href="Buy.php" class="a">Buy</a></li>
            <li><a href="Sale.php" class="a">Sale</a></li>
            <li><a href="Contact.php" class="a">Contact Us</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="headerimage">
    <div class="headeriamge1">
      <div class="house"></div>
    </div>
    <div class="headerimage2">
      <div class="buying"><a href="buy.php"> <img src="images/buyin.jpg" border="0" /></a> </div>
      <div class="selling"><a href="sale.php"> <img src="images/selling.jpg" border="0" /></a> </div>
    </div>
    <div>
    
    </div>
  </div>
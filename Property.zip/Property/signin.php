<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Way2Hostels | Home</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/style1.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
  color: #1CBCFA;
  font-weight: bold;
}
.style2 {
  color: #FD821B;
  font-weight: bold;
}
-->
</style>
</head>
<body>
<div class="main">
  <?php
  include "Headermenu.php"
  ?>
  <div style="height:300px; margin-bottom: 100px; margin-bottom: 100px; align-content: center;">
  <div class="content">
    <div class="innercontent">
      <div class="search">
    <div class="search1"></div>
    <center>
      
        <form name="form1" method="post" action="login.php">
         <table width="100%" bgcolor="#666666">
         <tr>
           <td class="style6">User Name:</td>
         </tr>
         <tr>
           <td><span id="sprytextfield1">
             <label>
             <input type="text" name="txtUserName" id="txtUserName">
             </label>
           <span class="textfieldRequiredMsg">*</span></span></td>
         </tr>
         <tr>
           <td class="style6">Password:</td>
         </tr>
         <tr>
           <td><span id="sprytextfield2">
             <label>
             <input type="password" name="txtPassword" id="txtPassword">
             </label>
           <span class="textfieldRequiredMsg">*</span></span></td>
         </tr>
         <tr>
           <td class="style6">User Type:</td>
         </tr>
         <tr>
           <td height="33"><label>
             <select name="cmbUserType" id="cmbUserType">
               <option>Admin</option>
               <option>Customer</option>
             </select>
           </label></td>
         </tr>
         <tr>
           <td height="36"><div align="center">
             <input type="submit" name="button" id="button" value="Submit">
           </div></td>
         </tr>
         <tr>
         <td><label></label></td>
         </tr>
         </table>
        </form>
    </center>    
      </div>
    </div>
  </div>
  <div>
  </div>
   <?php
   include "footer.php"
   ?>
  </div>
</div>
</body>
</html>
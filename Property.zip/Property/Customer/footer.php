 <div class="footer">
      <div class="text"> |&copy 2018 All Rights Reserved| Way2Hostels Pvt. Ltd. </div>

    </div>
